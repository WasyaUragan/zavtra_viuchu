#!/bin/bash

echo =============================
echo обновляю repo cache
apt update
echo =============================
echo устанавливаю необходимые пакеты на host
apt install debootstrap -y
echo =============================
echo создаю chroot
debootstrap bullseye /opt/chroot/ http://deb.debian.org/debian/
echo =============================
echo монтирую /dev в chroot 
mount --bind /dev /opt/chroot/dev
echo =============================
echo монтирую /proc в chroot 
mount --bind /proc /opt/chroot/proc
echo =============================
echo монтирую /sys в chroot 
mount --bind /sys /opt/chroot/sys
echo =============================
echo копирую конфигурацию dns в chroot
cp /etc/resolv.conf /opt/chroot/etc/
echo =============================
echo создаю директорию сборки
mkdir /opt/chroot/opt/build_dir
echo =============================
echo копирую скрипт в chroot
cp build_1.sh /opt/chroot/opt/build_dir
echo =============================
echo делаю скрипт исполняемым
chmod +x /opt/chroot/opt/build_dir/build_1.sh
echo =============================
echo исполняю скрипт внудри chroot
chroot /opt/chroot /opt/build_dir/build_1.sh
